package com.serenegiant.common;

/**
 * Created by Administrator on 2016/7/19.
 * Global constant to control logging, should always be set to false in
 *  released versions.
 */
public class UvcDebug {
    public static final boolean DEBUG = true;
}